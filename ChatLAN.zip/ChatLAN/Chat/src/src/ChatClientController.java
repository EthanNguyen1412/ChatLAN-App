package src;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.*;
import java.net.ConnectException;
import java.net.Socket;
import java.util.Optional;

public class ChatClientController {

    @FXML private TextArea chatArea;
    @FXML private TextField messageField;
    @FXML private Button sendButton;
    @FXML private ListView<String> userListView;
    @FXML private Label statusLabel;
    @FXML private VBox bossControls;
    @FXML private ComboBox<String> departmentSelector;

    private static final String CHAT_HISTORY_FILE_PREFIX = "chat_history_";
    private static final String SERVER_IP = "localhost";
    private static final int SERVER_PORT = 1234;

    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;
    
    private String currentUsername;
    private String department;
    private boolean isBoss = false;
    
    private String currentSelectedDepartment = null;

    @FXML
    public void initialize() {
        setChatUIDisabled(true);
        bossControls.setVisible(false);

        Platform.runLater(this::runLoginProcess);
    }
    
    private void runLoginProcess() {
        String lastError = null;
        while (currentUsername == null) {
            Optional<Pair<String, String>> result = showLoginDialog(lastError);

            if (!result.isPresent()) {
                closeApplication();
                return;
            }
            
            String username = result.get().getKey();
            String password = result.get().getValue();

            try {
                socket = new Socket(SERVER_IP, SERVER_PORT);
                out = new PrintWriter(socket.getOutputStream(), true);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                out.println("LOGIN:" + username + ":" + password);

                String response = in.readLine();
                if (response != null && response.startsWith("LOGIN_SUCCESS:")) {
                    processLoginSuccess(response);
                    break; 
                } else if (response != null && response.startsWith("ERROR:")) {
                    lastError = response.substring("ERROR:".length());
                    socket.close();
                } else {
                    lastError = "Phản hồi không hợp lệ từ server.";
                    socket.close();
                }
            } catch (ConnectException e) {
                showErrorAlert("Lỗi Kết Nối", "Không thể kết nối đến server.", "Vui lòng kiểm tra server có đang chạy không.");
                closeApplication();
                return;
            } catch (IOException e) {
                lastError = "Lỗi mạng: " + e.getMessage();
                if (socket != null && !socket.isClosed()) try { socket.close(); } catch (IOException ex) {}
            }
        }

        if (currentUsername != null) {
            activateChatUI();
            new Thread(this::listenForServerMessages).start();
        }
    }
    
    private void processLoginSuccess(String response) {
        String[] parts = response.split(":", 5);
        this.currentUsername = parts[1];
        this.department = parts[2];
        this.isBoss = Boolean.parseBoolean(parts[3]);
        if (this.isBoss) {
            Platform.runLater(() -> {
                String[] allDepartments = parts[4].split(",");
                departmentSelector.getItems().addAll(allDepartments);
                
                departmentSelector.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
                    if (newVal != null && !newVal.equals(oldVal)) {
                        switchToDepartment(newVal);
                    }
                });
                
                if (allDepartments.length > 0) {
                    departmentSelector.getSelectionModel().selectFirst();
                }
            });
        }
    }
    
    private void switchToDepartment(String newDepartment) {
        if (newDepartment.equals(currentSelectedDepartment)) return;
        
        // Lưu lại lịch sử chat hiện tại
        if (currentSelectedDepartment != null) {
            saveChatHistoryForDepartment(currentSelectedDepartment);
        }
        
        // Chuyển sang phòng ban mới
        currentSelectedDepartment = newDepartment;
        
        // Xóa chat area và load lịch sử của phòng ban mới
        chatArea.clear();
        loadChatHistoryForDepartment(currentSelectedDepartment);
        
        // Cập nhật trạng thái
        statusLabel.setText("Đang xem phòng ban: " + currentSelectedDepartment);
        
        // Yêu cầu danh sách users của phòng ban này
        out.println("REQUEST_DEPT_USERS:" + currentSelectedDepartment);
    }

    private Optional<Pair<String, String>> showLoginDialog(String errorMessage) {
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Đăng nhập Chat");
        dialog.setHeaderText("Nhập thông tin đăng nhập của bạn.");

        ButtonType loginButtonType = new ButtonType("Đăng nhập", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField usernameField = new TextField();
        usernameField.setPromptText("Tên đăng nhập");
        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Mật khẩu");
        
        Label errorLabel = new Label(errorMessage != null ? errorMessage : "");
        errorLabel.setStyle("-fx-text-fill: red;");

        grid.add(new Label("Tên đăng nhập:"), 0, 0);
        grid.add(usernameField, 1, 0);
        grid.add(new Label("Mật khẩu:"), 0, 1);
        grid.add(passwordField, 1, 1);
        grid.add(errorLabel, 0, 2, 2, 1);
        
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);
        
        usernameField.textProperty().addListener((obs, oldV, newV) -> {
            loginButton.setDisable(newV.trim().isEmpty() || passwordField.getText().trim().isEmpty());
        });
        passwordField.textProperty().addListener((obs, oldV, newV) -> {
            loginButton.setDisable(newV.trim().isEmpty() || usernameField.getText().trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);
        Platform.runLater(usernameField::requestFocus);

        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(usernameField.getText(), passwordField.getText());
            }
            return null;
        });

        return dialog.showAndWait();
    }
    
    private void activateChatUI() {
        if (isBoss) {
            // Sếp không load chat history ngay, sẽ load khi chọn phòng ban
            statusLabel.setText("Chọn phòng ban để xem chat");
            bossControls.setVisible(true);
        } else {
            // Nhân viên bình thường
            loadChatHistory();
            statusLabel.setText("Đã kết nối tới phòng ban: " + department);
        }

        setChatUIDisabled(false);
        messageField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) sendMessage();
        });

        Stage stage = (Stage) chatArea.getScene().getWindow();
        if (stage != null) {
            stage.setTitle("Chat Client - " + currentUsername);
            stage.setOnCloseRequest(event -> {
                if (out != null) out.println("DISCONNECT:");
                closeApplication();
            });
        }
    }

    private void listenForServerMessages() {
        try {
            String serverMessage;
            while ((serverMessage = in.readLine()) != null) {
                final String finalMessage = serverMessage;
                Platform.runLater(() -> processServerMessage(finalMessage));
            }
        } catch (IOException e) {
            if (!socket.isClosed()) {
                Platform.runLater(() -> {
                    showErrorAlert("Mất Kết Nối", "Mất kết nối với server.", e.getMessage());
                    setChatUIDisabled(true);
                    statusLabel.setText("Đã mất kết nối.");
                });
            }
        }
    }

    private void processServerMessage(String message) {
        if (message.startsWith("PUBLIC_MSG:")) {
            String content = message.substring("PUBLIC_MSG:".length());
            appendMessageToChatArea(content);
        } else if (message.startsWith("PRIVATE_MSG:")) {
            appendMessageToChatArea("[Riêng tư] " + message.substring("PRIVATE_MSG:".length()));
        } else if (message.startsWith("USERS:") || message.startsWith("ALL_USERS:")) {
            String[] users = message.substring(message.indexOf(":") + 1).split(",");
            userListView.getItems().clear();
            for (String user : users) {
                if (!user.isEmpty()) userListView.getItems().add(user);
            }
        } else if (message.startsWith("DEPT_USERS:")) {
            // Phản hồi danh sách users của phòng ban cụ thể (cho sếp)
            String[] parts = message.split(":", 3);
            if (parts.length >= 3) {
                String deptName = parts[1];
                String[] users = parts[2].split(",");
                
                // Chỉ cập nhật nếu đây là phòng ban hiện tại sếp đang xem
                if (isBoss && deptName.equals(currentSelectedDepartment)) {
                    userListView.getItems().clear();
                    for (String user : users) {
                        if (!user.isEmpty()) userListView.getItems().add(user);
                    }
                }
            }
        } else if (message.startsWith("ERROR:")) {
            appendMessageToChatArea("[LỖI SERVER]: " + message.substring("ERROR:".length()));
        } else if (message.startsWith("SERVER_SHUTDOWN:")) {
            appendMessageToChatArea("[THÔNG BÁO] " + message.substring("SERVER_SHUTDOWN:".length()));
            setChatUIDisabled(true);
        } else {
             appendMessageToChatArea("[Không rõ] " + message);
        }
    }

    @FXML
    private void sendMessage() {
        String message = messageField.getText().trim();
        if (message.isEmpty() || out == null) return;

        String selectedUser = userListView.getSelectionModel().getSelectedItem();
        
        if (selectedUser != null && !selectedUser.equals(currentUsername)) {
            // Gửi tin nhắn riêng tư
            out.println("@" + selectedUser + ":" + message);
            appendMessageToChatArea("[Bạn tới " + selectedUser.split(" ")[0] + "]: " + message);
        } else {
            // Gửi tin nhắn công khai
            if(isBoss && currentSelectedDepartment != null) {
                // Sếp gửi tin nhắn tới phòng ban đang chọn
                out.println("BOSS_MSG:" + currentSelectedDepartment + ":" + message);
            } else if (!isBoss) {
                // Nhân viên gửi tin nhắn trong phòng ban của mình
                out.println("PUBLIC:" + message);
            }
        }
        messageField.clear();
    }
    
    private void setChatUIDisabled(boolean disabled) {
        messageField.setDisable(disabled);
        sendButton.setDisable(disabled);
        userListView.setDisable(disabled);
    }

    private void appendMessageToChatArea(String message) {
        chatArea.appendText(message + "\n");
        if (isBoss && currentSelectedDepartment != null) {
            saveMessageToHistoryForDepartment(currentSelectedDepartment, message);
        } else if (!isBoss) {
            saveMessageToHistory(message);
        }
    }
    
    // Phương thức cũ cho nhân viên
    private void loadChatHistory() {
        File historyFile = new File(CHAT_HISTORY_FILE_PREFIX + currentUsername + ".txt");
        if (historyFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(historyFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    chatArea.appendText(line + "\n");
                }
            } catch (IOException e) {
                System.err.println("Lỗi đọc lịch sử chat: " + e.getMessage());
            }
        }
    }

    private void saveMessageToHistory(String message) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CHAT_HISTORY_FILE_PREFIX + currentUsername + ".txt", true))) {
            writer.write(message);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Lỗi ghi lịch sử chat: " + e.getMessage());
        }
    }
    
    //load lịch sử theo phòng ban
    private void loadChatHistoryForDepartment(String deptName) {
        File historyFile = new File(CHAT_HISTORY_FILE_PREFIX + currentUsername + "_" + deptName + ".txt");
        if (historyFile.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(historyFile))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    chatArea.appendText(line + "\n");
                }
            } catch (IOException e) {
                System.err.println("Lỗi đọc lịch sử chat phòng ban " + deptName + ": " + e.getMessage());
            }
        }
    }

    private void saveMessageToHistoryForDepartment(String deptName, String message) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CHAT_HISTORY_FILE_PREFIX + currentUsername + "_" + deptName + ".txt", true))) {
            writer.write(message);
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Lỗi ghi lịch sử chat phòng ban " + deptName + ": " + e.getMessage());
        }
    }
    
    private void saveChatHistoryForDepartment(String deptName) {
        // Lưu dung chat area hiện tại vào file của phòng ban
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(CHAT_HISTORY_FILE_PREFIX + currentUsername + "_" + deptName + ".txt"))) {
            writer.write(chatArea.getText());
        } catch (IOException e) {
            System.err.println("Lỗi lưu lịch sử chat phòng ban " + deptName + ": " + e.getMessage());
        }
    }
    
    private void showErrorAlert(String title, String header, String content) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(header);
        alert.setContentText(content);
        alert.showAndWait();
    }

    private void closeApplication() {
        // Lưu lịch sử chat hiện tại trước khi đóng
        if (isBoss && currentSelectedDepartment != null) {
            saveChatHistoryForDepartment(currentSelectedDepartment);
        }
        
        try {
            if (out != null) out.close();
            if (in != null) in.close();
            if (socket != null && !socket.isClosed()) socket.close();
        } catch (IOException e) {
        } finally {
            Platform.exit();
            System.exit(0);
        }
    }
    
    // trả về 2 giá trị từ dialog
    private static class Pair<K, V> {
        private final K key;
        private final V value;
        public Pair(K key, V value) { this.key = key; this.value = value; }
        public K getKey() { return key; }
        public V getValue() { return value; }
    }
}