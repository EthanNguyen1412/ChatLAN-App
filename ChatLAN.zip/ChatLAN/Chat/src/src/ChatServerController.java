package src;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class ChatServerController {

    @FXML private TextArea serverLogArea;
    @FXML private ListView<String> connectedClientsList;
    @FXML private Label statusLabel;
    @FXML private TextField serverMessageField;
    @FXML private Button sendPrivateMessageButton;
    @FXML private Label privateRecipientLabel;
    @FXML private Label clientCountLabel;
    @FXML private Button startButton;
    @FXML private Button stopButton;
    @FXML private TextField broadcastMessageField;
    @FXML private Button sendBroadcastButton;

    private static final int PORT = 1234;
    private ServerSocket serverSocket;
    private Thread serverThread;
    private volatile boolean isServerRunning = false;


    static class User {
        String username;
        String password;
        String department;
        boolean isBoss;
        PrintWriter writer;
        Socket socket;

        User(String username, String password, String department, boolean isBoss) {
            this.username = username;
            this.password = password;
            this.department = department;
            this.isBoss = isBoss;
        }

        @Override
        public String toString() {
            return username + " (" + (isBoss ? "Boss" : department) + ")";
        }
    }

    private final Map<String, User> userCredentials = new ConcurrentHashMap<>();
    final Map<String, User> loggedInUsers = new ConcurrentHashMap<>();

    @FXML
    public void initialize() {
        setupInitialUIState();
        loadUsers(); // Tải thông tin người dùng được định cấu hình sẵn

        // Listener để gửi tin nhắn riêng tư
        connectedClientsList.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, newVal) -> {
            if (newVal != null) {
                privateRecipientLabel.setText("Gửi tới: " + newVal);
                serverMessageField.setDisable(false);
                sendPrivateMessageButton.setDisable(false);
            } else {
                privateRecipientLabel.setText("Chọn Client để gửi riêng.");
                serverMessageField.setDisable(true);
                sendPrivateMessageButton.setDisable(true);
            }
        });
        
        serverMessageField.setOnKeyPressed(e -> { if (e.getCode() == KeyCode.ENTER) sendPrivateMessageFromServer(); });
        broadcastMessageField.setOnKeyPressed(e -> { if (e.getCode() == KeyCode.ENTER) sendBroadcastMessageFromServer(); });
    }

    private void loadUsers() {
        userCredentials.put("sep", new User("sep", "1", "BOSS", true));
        userCredentials.put("bao", new User("bao", "1", "Kế toán", false));
        userCredentials.put("vu", new User("vu", "1", "Kế toán", false));
        userCredentials.put("vanh", new User("vanh", "1", "Kỹ thuật", false));
        userCredentials.put("luc", new User("luc", "1", "Kỹ thuật", false));
        userCredentials.put("nigga", new User("nigga", "1", "Marketing", false));
        userCredentials.put("nick", new User("nick", "1", "Marketing", false));
    }

    @FXML
    private void startServer() {
        if (isServerRunning) return;
        try {
            serverSocket = new ServerSocket(PORT);
            isServerRunning = true;
            appendLog("Server đã khởi động trên cổng " + PORT);
            updateUIForServerRunning(true);

            serverThread = new Thread(this::acceptConnections);
            serverThread.start();
        } catch (IOException e) {
            appendLog("Lỗi khởi động server: " + e.getMessage());
            updateUIForServerRunning(false);
        }
    }

    private void acceptConnections() {
        while (isServerRunning) {
            try {
                Socket clientSocket = serverSocket.accept();
                new Thread(new ClientHandler(clientSocket, this)).start();
            } catch (IOException e) {
                if (isServerRunning) {
                    appendLog("Lỗi chấp nhận kết nối: " + e.getMessage());
                }
            }
        }
    }

    @FXML
    public void stopServer() {
        if (!isServerRunning) return;
        isServerRunning = false;

        broadcastToAll("SERVER_SHUTDOWN:Server đã đóng. Vui lòng kết nối lại sau.");

        try {
            if (serverSocket != null && !serverSocket.isClosed()) {
                serverSocket.close();
            }
        } catch (IOException e) {
            appendLog("Lỗi khi đóng ServerSocket: " + e.getMessage());
        } finally {
            loggedInUsers.values().forEach(user -> {
                try {
                    if (user.socket != null) user.socket.close();
                } catch (IOException e) {}
            });
            loggedInUsers.clear();
            updateUIForServerRunning(false);
            updateConnectedClientsUI();
            appendLog("Server đã dừng.");
        }
    }

    public synchronized void handleLogin(String username, String password, PrintWriter writer, Socket socket) {
        User user = userCredentials.get(username);

        if (user == null) {
            writer.println("ERROR:Tên người dùng không tồn tại.");
        } else if (!user.password.equals(password)) {
            writer.println("ERROR:Sai mật khẩu.");
        } else if (loggedInUsers.containsKey(username)) {
            writer.println("ERROR:Người dùng đã đăng nhập.");
        } else {
            user.writer = writer;
            user.socket = socket;
            loggedInUsers.put(username, user);

            String allDepartments = userCredentials.values().stream()
                .map(u -> u.department)
                .filter(dept -> !dept.equals("BOSS"))
                .distinct()
                .collect(Collectors.joining(","));
            
            writer.println("LOGIN_SUCCESS:" + user.username + ":" + user.department + ":" + user.isBoss + ":" + allDepartments);
            
            appendLog(user + " đã tham gia.");
            // Chỉ thông báo tới phòng ban nếu không phải là sếp
            if (!user.isBoss) {
                broadcastToDepartment(user.department, "Server: " + user.username + " đã tham gia phòng chat.", "Server");
            }
            
            updateUserLists();
        }
    }

    public synchronized void handleLogout(String username) {
        User user = loggedInUsers.remove(username);
        if (user != null) {
            appendLog(user + " đã rời đi.");
            // Chỉ thông báo tới phòng ban nếu không phải là sếp
            if (!user.isBoss) {
                broadcastToDepartment(user.department, "Server: " + user.username + " đã rời phòng chat.", "Server");
            }
            
            updateUserLists();
        }
    }

    public void broadcastToDepartment(String department, String message, String sender) {
        String formattedMessage = "PUBLIC_MSG:[" + department + "] " + sender + ": " + message;
        appendLog("["+department+"] " + sender + ": " + message);

        for (User user : loggedInUsers.values()) {
            if (user.isBoss || user.department.equals(department)) {
                user.writer.println(formattedMessage);
            }
        }
    }
    
    public void broadcastToAll(String message) {
        appendLog("BROADCAST: " + message);
        for (User user : loggedInUsers.values()) {
            user.writer.println(message);
        }
    }
    
    public void handlePrivateMessage(String senderUsername, String recipientUsername, String message) {
        User sender = loggedInUsers.get(senderUsername);
        User recipient = loggedInUsers.get(recipientUsername);
        
        if (recipient == null) {
            sender.writer.println("ERROR:Người dùng '" + recipientUsername + "' không trực tuyến.");
            return;
        }

        if (sender.isBoss || recipient.isBoss || sender.department.equals(recipient.department)) {
            String formattedMessage = "PRIVATE_MSG:" + senderUsername + " (tới bạn): " + message;
            recipient.writer.println(formattedMessage);
            appendLog("[Riêng tư] " + senderUsername + " -> " + recipientUsername + ": " + message);
        } else {
            sender.writer.println("ERROR:Bạn không thể gửi tin nhắn cho người dùng ở phòng ban khác.");
        }
    }

    public void handleDepartmentUsersRequest(String requesterUsername, String departmentName) {
        User requester = loggedInUsers.get(requesterUsername);
        
        // Chỉ sếp mới được yêu cầu danh sách users của phòng ban
        if (requester == null || !requester.isBoss) {
            return;
        }
        
        // Lấy danh sách users của phòng ban được yêu cầu (bao gồm cả sếp)
        String deptUserList = loggedInUsers.values().stream()
            .filter(u -> u.department.equals(departmentName) || u.isBoss)
            .map(User::toString)
            .collect(Collectors.joining(","));
        
        // Gửi danh sách về cho sếp
        requester.writer.println("DEPT_USERS:" + departmentName + ":" + deptUserList);
        
        appendLog("Đã gửi danh sách users phòng ban " + departmentName + " cho sếp " + requesterUsername);
    }

    public void updateUserLists() {
        // Gửi danh sách tất cả users cho sếp
        String allUsersList = "ALL_USERS:" + loggedInUsers.values().stream()
            .map(User::toString).collect(Collectors.joining(","));
        
        loggedInUsers.values().stream()
            .filter(u -> u.isBoss)
            .forEach(boss -> boss.writer.println(allUsersList));
            
        // Gửi danh sách users theo phòng ban cho nhân viên
        Set<String> departments = loggedInUsers.values().stream()
            .filter(u -> !u.isBoss)
            .map(u -> u.department)
            .collect(Collectors.toSet());

        for (String dept : departments) {
            String deptUserList = "USERS:" + loggedInUsers.values().stream()
                .filter(u -> u.department.equals(dept) || u.isBoss)
                .map(User::toString)
                .collect(Collectors.joining(","));
            
            loggedInUsers.values().stream()
                .filter(u -> !u.isBoss && u.department.equals(dept))
                .forEach(u -> u.writer.println(deptUserList));
        }
        updateConnectedClientsUI();
    }
    
    @FXML
    private void sendPrivateMessageFromServer() {
        String selection = connectedClientsList.getSelectionModel().getSelectedItem();
        if (selection == null || serverMessageField.getText().trim().isEmpty()) return;
        
        String recipientUsername = selection.split(" ")[0];
        String message = serverMessageField.getText().trim();
        
        User recipient = loggedInUsers.get(recipientUsername);
        if (recipient != null) {
            recipient.writer.println("PRIVATE_MSG:Server (tới bạn): " + message);
            appendLog("[Riêng tư] Server -> " + recipientUsername + ": " + message);
        } else {
            appendLog("Lỗi: Không tìm thấy client " + recipientUsername);
        }
        serverMessageField.clear();
    }
    
    @FXML
    private void sendBroadcastMessageFromServer() {
        String message = broadcastMessageField.getText().trim();
        if(message.isEmpty()) return;
        broadcastToAll("PUBLIC_MSG:[Server Toàn Cầu]: " + message);
        broadcastMessageField.clear();
    }

    private void updateUIForServerRunning(boolean running) {
        Platform.runLater(() -> {
            statusLabel.setText(running ? "Server đang chạy..." : "Server đang dừng.");
            startButton.setDisable(running);
            stopButton.setDisable(!running);
            broadcastMessageField.setDisable(!running);
            sendBroadcastButton.setDisable(!running);
            if (!running) {
                serverMessageField.setDisable(true);
                sendPrivateMessageButton.setDisable(true);
                privateRecipientLabel.setText("Chọn Client để gửi riêng.");
            }
        });
    }

    private void updateConnectedClientsUI() {
        Platform.runLater(() -> {
            connectedClientsList.getItems().setAll(
                loggedInUsers.values().stream().map(User::toString).sorted().collect(Collectors.toList())
            );
            clientCountLabel.setText("Clients kết nối: " + loggedInUsers.size());
        });
    }
    
    private void setupInitialUIState() {
        statusLabel.setText("Server đang dừng.");
        stopButton.setDisable(true);
        startButton.setDisable(false);
        sendPrivateMessageButton.setDisable(true);
        serverMessageField.setDisable(true);
        broadcastMessageField.setDisable(true);
        sendBroadcastButton.setDisable(true);
        privateRecipientLabel.setText("Chọn Client để gửi riêng.");
    }
    
    public void appendLog(String message) {
        Platform.runLater(() -> serverLogArea.appendText(message + "\n"));
    }
    
    @FXML private void clearLog() {
        serverLogArea.clear();
    }
}

class ClientHandler implements Runnable {
    private Socket socket;
    private ChatServerController controller;
    private String username;
    private PrintWriter out;
    private BufferedReader in;

    public ClientHandler(Socket socket, ChatServerController controller) {
        this.socket = socket;
        this.controller = controller;
    }

    @Override
    public void run() {
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            String loginMessage = in.readLine();
            if (loginMessage != null && loginMessage.startsWith("LOGIN:")) {
                String[] credentials = loginMessage.substring("LOGIN:".length()).split(":", 2);
                if (credentials.length == 2) {
                    this.username = credentials[0];
                    controller.handleLogin(this.username, credentials[1], out, socket);
                }
            }

            if (controller.loggedInUsers.get(this.username) == null) {
                return; 
            }

            String message;
            while ((message = in.readLine()) != null) {
                if (message.startsWith("DISCONNECT:")) {
                    break;
                } else if (message.startsWith("@")) {
                    int colonIndex = message.indexOf(":");
                    if (colonIndex > 1) {
                        String recipientUsername = message.substring(1, colonIndex).split(" ")[0];
                        String pmContent = message.substring(colonIndex + 1);
                        controller.handlePrivateMessage(this.username, recipientUsername, pmContent);
                    }
                } else if (message.startsWith("PUBLIC:")) {
                    String department = controller.loggedInUsers.get(this.username).department;
                    String content = message.substring("PUBLIC:".length());
                    controller.broadcastToDepartment(department, content, this.username);
                } else if (message.startsWith("BOSS_MSG:")) {
                    // Xử lý tin nhắn từ sếp gửi tới phòng ban cụ thể
                    String[] parts = message.substring("BOSS_MSG:".length()).split(":", 2);
                    if (parts.length == 2) {
                        String targetDepartment = parts[0];
                        String content = parts[1];
                        controller.broadcastToDepartment(targetDepartment, content, this.username);
                    }
                } else if (message.startsWith("REQUEST_DEPT_USERS:")) {
                    // Xử lý yêu cầu danh sách users của phòng ban cụ thể
                    String departmentName = message.substring("REQUEST_DEPT_USERS:".length());
                    controller.handleDepartmentUsersRequest(this.username, departmentName);
                }
            }
        } catch (IOException e) {
            // Client ngắt kết nối đột ngột
        } finally {
            if (this.username != null) {
                controller.handleLogout(this.username);
            }
            try {
                socket.close();
            } catch (IOException e) {
                controller.appendLog("Lỗi đóng socket cho " + username + ": " + e.getMessage());
            }
        }
    }
}