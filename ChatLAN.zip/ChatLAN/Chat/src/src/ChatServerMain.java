package src;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class ChatServerMain extends Application {

    private ChatServerController serverController; // Tham chiếu đến controller

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("ChatServer.fxml"));
        Parent root = loader.load();

        serverController = loader.getController();

        Scene scene = new Scene(root, 650, 500);
        scene.getStylesheets().add(getClass().getResource("ChatServer.css").toExternalForm());

        primaryStage.setTitle("Chat Server - Hệ thống quản lý chat phòng ban");
        primaryStage.setScene(scene);
        primaryStage.show();

        // Server dừng khi cửa sổ đóng
        primaryStage.setOnCloseRequest(event -> {
            if (serverController != null) {
                serverController.stopServer();
            }
            javafx.application.Platform.exit();
            System.exit(0);
        });
    }

    public static void main(String[] args) {
        launch(args);
    }
}